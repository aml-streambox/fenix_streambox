; DEF file for MS VC++

EXPORTS
  XML_DefaultCurrent @1
  XML_ErrorString @2
  XML_ExpatVersion @3
  XML_ExpatVersionInfo @4
  XML_ExternalEntityParserCreate @5
  XML_GetBase @6
  XML_GetBuffer @7
  XML_GetCurrentByteCount @8
  XML_GetCurrentByteIndex @9
  XML_GetCurrentColumnNumber @10
  XML_GetCurrentLineNumber @11
  XML_GetErrorCode @12
  XML_GetIdAttributeIndex @13
  XML_GetInputContext @14
  XML_GetSpecifiedAttributeCount @15
  XML_Parse @16
  XML_ParseBuffer @17
  XML_ParserCreate @18
  XML_ParserCreateNS @19
  XML_ParserCreate_MM @20
  XML_ParserFree @21
  XML_SetAttlistDeclHandler @22
  XML_SetBase @23
  XML_SetCdataSectionHandler @24
  XML_SetCharacterDataHandler @25
  XML_SetCommentHandler @26
  XML_SetDefaultHandler @27
  XML_SetDefaultHandlerExpand @28
  XML_SetDoctypeDeclHandler @29
  XML_SetElementDeclHandler @30
  XML_SetElementHandler @31
  XML_SetEncoding @32
  XML_SetEndCdataSectionHandler @33
  XML_SetEndDoctypeDeclHandler @34
  XML_SetEndElementHandler @35
  XML_SetEndNamespaceDeclHandler @36
  XML_SetEntityDeclHandler @37
  XML_SetExternalEntityRefHandler @38
  XML_SetExternalEntityRefHandlerArg @39
  XML_SetNamespaceDeclHandler @40
  XML_SetNotStandaloneHandler @41
  XML_SetNotationDeclHandler @42
  XML_SetParamEntityParsing @43
  XML_SetProcessingInstructionHandler @44
  XML_SetReturnNSTriplet @45
  XML_SetStartCdataSectionHandler @46
  XML_SetStartDoctypeDeclHandler @47
  XML_SetStartElementHandler @48
  XML_SetStartNamespaceDeclHandler @49
  XML_SetUnknownEncodingHandler @50
  XML_SetUnparsedEntityDeclHandler @51
  XML_SetUserData @52
  XML_SetXmlDeclHandler @53
  XML_UseParserAsHandlerArg @54
; added with version 1.95.3
  XML_ParserReset @55
  XML_SetSkippedEntityHandler @56
; added with version 1.95.5
  XML_GetFeatureList @57
  XML_UseForeignDTD @58
; added with version 1.95.6
  XML_FreeContentModel @59
  XML_MemMalloc @60
  XML_MemRealloc @61
  XML_MemFree @62
; added with version 1.95.8
  XML_StopParser @63
  XML_ResumeParser @64
  XML_GetParsingStatus @65
; added with version 2.1.1
@_EXPAT_COMMENT_ATTR_INFO@ XML_GetAttributeInfo @66
  XML_SetHashSalt @67
; internal @68 removed with version 2.3.1
; added with version 2.4.0
@_EXPAT_COMMENT_DTD_OR_GE@ XML_SetBillionLaughsAttackProtectionActivationThreshold @69
@_EXPAT_COMMENT_DTD_OR_GE@ XML_SetBillionLaughsAttackProtectionMaximumAmplification @70
; added with version 2.6.0
  XML_SetReparseDeferralEnabled @71
